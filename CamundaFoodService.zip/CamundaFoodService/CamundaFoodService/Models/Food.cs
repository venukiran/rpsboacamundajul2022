﻿namespace CamundaFoodService.Models
{
    public class Food
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public int Qty { get; set; }

    }
}
